/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projekt;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author hallgato
 */
public class HalalLabirintus {

    public static void main(String[] args) {

        Random rnd = new Random();

        int elet = 0;
        int szerencse = 0;
        int ugyesseg = 0;
        int aranyPenz = 0;
        
        for (int hp = 1; hp <= 2; hp++) {
            int hpdobas = rnd.nextInt(6) + 1;
            elet += hpdobas;
        }
        
        int szerencsedobas = rnd.nextInt(6) + 1;
        int ugyessegdobas = rnd.nextInt(6) + 1;
        szerencse += szerencsedobas;
        ugyesseg += ugyessegdobas;

        System.out.printf("Ügyesség: %d \n", ugyesseg + 6);
        System.out.printf("Életerő: %d \n", elet + 12);
        System.out.printf("Szerencse: %d \n", szerencse + 6);
        
        int oldalSzam = 0;
        String oldal = ". oldal";
        
        System.out.println(" \n Miután öt percet haladtál lassan az alagútban, egy kőasztalhoz érsz, amely a bal oldali fal mellett áll. \n " +
                "Hat doboz van rajta, egyikükre a te neved festették. \n " +
                "Ha kiakarod nyitni a dobozt, lapozz a 270-re. \n " +
                "Ha inkább tovább haladsz észak felé, lapozz a 66-ra. \n ");
        
        Scanner scan = new Scanner(System.in);
        oldalSzam = scan.nextInt();
        
        if (oldalSzam == 270){
            System.out.println(oldalSzam + oldal);
            System.out.println(" \n A doboz teteje könnyedén nyílik. \n " +
                    "Benne két aranypénzt találsz, és egy üzenetet, amely egy kis pergamenen neked szól. \n " +
                    "Előbb zsebre vágod az aranyakat, aztán elolvasod az üzenetet: - „Jól tetted. Legalább volt annyi eszed, hogy megállj és elfogadd az ajándékot. \n " +
                    "Most azt tanácsolom neked, hogy keress és használj különféle tárgyakat, ha sikerrel akarsz áthaladni Halállabirintusomon.” Azaláírás Szukumvit. \n " +
                    "Megjegyzed a tanácsot, apródarabokra téped a pergament, és tovább mészészak felé. Lapozz a 66-ra. \n ");
        
        oldalSzam = scan.nextInt();
        aranyPenz += 2;
        }
        
        if (oldalSzam == 66){
            System.out.println(oldalSzam + oldal);
            System.out.println(" \n Néhány perc gyaloglás után egy elágazáshoz érsz az alagútban. \n " +
                    "Egy, a falra festett fehér nyíl nyugatfelé mutat. \n " +
                    "A földön nedves lábnyomok jelzik, merre haladtak az előtted járók. \n " +
                    "Nehéz biztosan megmondani, de úgy tűnik, hogy három közülük a nyíl irányába halad, míg egyikük úgy döntött, hogy keletnek megy. \n " +
                    "Ha nyugat felé kívánsz menni, lapozz a 293-ra. Ha keletnek, lapozz a 56-re. \n ");
        
        oldalSzam = scan.nextInt();
        }
        
        if (oldalSzam == 293){
            System.out.println(oldalSzam + oldal);
            System.out.println(" \n A három pár nedves lábnyomot követve az alagútnyugati elágazásában hamarosan egy újabb el-ágazáshoz érsz. \n " +
                    "Ha továbbmész nyugat felé a lábnyomokat követve, lapozz a 137-re. \n " +
                    "Ha inkább észak felé mész a harmadik pár lábnyom után, lapozz a 387-re \n ");
            
        oldalSzam = scan.nextInt();
        }
        
        if (oldalSzam == 137){
            System.out.println(oldalSzam + oldal);
            System.out.println("Ahogy végigmész az alagúton, csodálkozva látod, hogy egy jókora vasharang csüng alá a boltozatról.");
            
            System.out.println("Kalandod véget ért. Végleges statjaid: ");
            System.out.printf("Ügyesség: %d \n", ugyesseg + 6);
            System.out.printf("Életerő: %d \n", elet + 12);
            System.out.printf("Szerencse: %d \n", szerencse + 6);
            System.out.printf("Aranypénz: %d \n", aranyPenz);
        }
        
        if (oldalSzam == 387){
            System.out.println(oldalSzam + oldal);
            System.out.println(" \n Hallod, hogy elölről súlyos lépések közelednek. \n "
                    + "Egy széles, állatbőrökbe öltözött, kőbaltás, primitívlény lép elő. \n "
                    + "Ahogy meglát, morog, a földre köp, majd a kőbaltát felemelve közeledik, és mindennek kinéz, csak barátságosnak nem. \n "
                    + "Előhúzod kardodat, és felkészülsz, hogy megküzdj a Barlangi Emberrel. \n "
                    + "Barlangi Ember ÜGYESSÉG 7 ÉLETERŐ 7");
            
            System.out.println("Kalandod véget ért. Végleges statjaid: ");
            System.out.printf("Ügyesség: %d \n", ugyesseg + 6);
            System.out.printf("Életerő: %d \n", elet + 12);
            System.out.printf("Szerencse: %d \n", szerencse + 6);
            System.out.printf("Aranypénz: %d \n", aranyPenz);
        }
        
        if (oldalSzam == 56){
            System.out.println(oldalSzam + oldal);
            System.out.println(" \n Látod, hogy az akadály egy széles, barna, sziklaszerű tárgy. \n " +
                    "Megérinted, és meglepve tapasztalod, hogy lágy, szivacsszerű. \n " +
                    "Ha át szeretnél mászni rajta, lapozz a 373-ra. \n " +
                    "Ha ketté akarod vágni a kardoddal, lapozz a 215-re \n ");
            
        oldalSzam = scan.nextInt();
        }
        
        if (oldalSzam == 373){
            System.out.println(oldalSzam + oldal);
            System.out.println(" \n Fölmászol a lágy sziklára, attól tartasz, hogy bár-melyik pillanatban elnyelhet. \n "
                    + "Nehéz átvergődni rajta, mert puha anyagában alig tudod a lábadat emelni, de végül átvergődsz rajta. \n "
                    + "Megkönnyebbülten érsz újra szilárd talajra, és fordulsz kelet felé. \n ");
            
            System.out.println("Kalandod véget ért. Végleges statjaid: ");
            System.out.printf("Ügyesség: %d \n", ugyesseg + 6);
            System.out.printf("Életerő: %d \n", elet + 12);
            System.out.printf("Szerencse: %d \n", szerencse + 6);
            System.out.printf("Aranypénz: %d \n", aranyPenz);
        }
        
        if (oldalSzam == 215){
            System.out.println(oldalSzam + oldal);
            System.out.println(" \n Kardod könnyedén áthatol a spóragolyó vékonykülső burkán. Sűrű barna spórafelhő csap ki a golyóból, és körülvesz. \n "
                    + "Némelyik spóra a bőrödhöz tapad, és rettenetes viszketést okoz. Nagy daganatok nőnek az arcodon és karodon, és a bőröd mintha égne. \n "
                    + "2 ÉLETERŐ pontot veszítesz. Vadul vakarózva átléped a leeresztett golyót, és keletnek veszed az utad. \n ");
        
            System.out.println("Kalandod véget ért. Végleges statjaid: ");
            System.out.printf("Ügyesség: %d \n", ugyesseg + 6);
            System.out.printf("Életerő: %d \n", elet + 12 - 2);
            System.out.printf("Szerencse: %d \n", szerencse + 6);
            System.out.printf("Aranypénz: %d \n", aranyPenz);
        }
        
        }

}
