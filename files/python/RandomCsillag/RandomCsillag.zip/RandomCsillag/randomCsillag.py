from turtle import *
from random import *

bgcolor("black")

a = randint(50, 60)

for _ in range(a):
    x = randint(-300, 300)
    y = randint(-300, 300)
    a = randint(20, 30)
    b = randint(20, 50)
    c = randint(130, 190)
    d = randint(10, 100)
    speed(d)

    r = randint(0, 4)
    if r == 1:
        color("green", "purple")

    elif r == 2:
        color("red", "yellow")

    else:
        color("blue", "beige")

    begin_fill()
    for _ in range(a):

        forward(b)
        left(c)
    end_fill()

    penup()
    goto(x, y)
    pendown()

done()
