nem = input("Nem: ")
szoveg = ""
hibauzenet = "Rossz adatot adott meg!"
#Itt ellenőrzi, hogy jó nemet adott-e meg.

if nem == "Férfi" or nem == "férfi" or nem == "Nő" or nem == "nő":
    eletkor = int(input("Életkor: "))
    tomeg = int(input("Testtömeg: "))
    magassag = int(input("Magasság(cm): "))
    keplet = tomeg / (magassag / 100)**2  #ezzel számoljuk a bmi-t
    kg = 0

    #Itt adja meg a férfi nem melyikbe tartozik

    if nem == "Férfi" or nem == "férfi":
        if 18 <= eletkor <= 24:
            if keplet < 20:
                szoveg = "sovány"
            elif 20 <= keplet <= 25:
                szoveg = "ideális"
            elif 25 < keplet <= 30:
                szoveg = "Túlsúly"
            elif 30 < keplet <= 40:
                szoveg = "Elhízott"
            elif 40 < keplet:
                szoveg = "Súlyosan elhízott"
        elif 25 <= eletkor <= 34:
            if keplet < 21:
                szoveg = "sovány"
            elif 21 <= keplet <= 26:
                szoveg = "ideális"
            elif 26 < keplet <= 31:
                szoveg = "Túlsúly"
            elif 31 < keplet <= 41:
                szoveg = "Elhízott"
            elif 41 < keplet:
                szoveg = "Súlyosan elhízott"
        elif 35 <= eletkor <= 44:
            if keplet < 22:
                szoveg = "sovány"
            elif 22 <= keplet <= 27:
                szoveg = "ideális"
            elif 27 < keplet <= 32:
                szoveg = "Túlsúly"
            elif 32 < keplet <= 42:
                szoveg = "Elhízott"
            elif 42 < keplet:
                szoveg = "Súlyosan elhízott"
        elif 45 <= eletkor <= 54:
            if keplet < 23:
                szoveg = "sovány"
            elif 23 <= keplet <= 28:
                szoveg = "ideális"
            elif 28 < keplet <= 33:
                szoveg = "Túlsúly"
            elif 33 < keplet <= 43:
                szoveg = "Elhízott"
            elif 43 < keplet:
                szoveg = "Súlyosan elhízott"
        elif 55 <= eletkor <= 64:
            if keplet < 24:
                szoveg = "sovány"
            elif 24 <= keplet <= 29:
                szoveg = "ideális"
            elif 29 < keplet <= 34:
                szoveg = "Túlsúly"
            elif 34 < keplet <= 44:
                szoveg = "Elhízott"
            elif 44 < keplet:
                szoveg = "Súlyosan elhízott"
        elif 65 <= eletkor:
            if keplet < 25:
                szoveg = "sovány"
            elif 25 <= keplet <= 30:
                szoveg = "ideális"
            elif 30 < keplet <= 35:
                szoveg = "Túlsúly"
            elif 35 < keplet <= 45:
                szoveg = "Elhízott"
            elif 45 < keplet:
                szoveg = "Súlyosan elhízott"

# Itt adja meg a női nem melyikbe tartozik

    if nem == "Nő" or nem == "nő":
        if 18 <= eletkor <= 24:
            if keplet < 19:
                szoveg = "sovány"
            elif 19 <= keplet <= 24:
                szoveg = "ideális"
            elif 24 < keplet <= 29:
                szoveg = "Túlsúly"
            elif 29 < keplet <= 39:
                szoveg = "Elhízott"
            elif 39 < keplet:
                szoveg = "Súlyosan elhízott"
        elif 25 <= eletkor <= 34:
            if keplet < 20:
                szoveg = "sovány"
            elif 20 <= keplet <= 25:
                szoveg = "ideális"
            elif 25 < keplet <= 30:
                szoveg = "Túlsúly"
            elif 30 < keplet <= 40:
                szoveg = "Elhízott"
            elif 40 < keplet:
                szoveg = "Súlyosan elhízott"
        elif 35 <= eletkor <= 44:
            if keplet < 21:
                szoveg = "sovány"
            elif 21 <= keplet <= 26:
                szoveg = "ideális"
            elif 28 < keplet <= 31:
                szoveg = "Túlsúly"
            elif 31 < keplet <= 41:
                szoveg = "Elhízott"
            elif 41 < keplet:
                szoveg = "Súlyosan elhízott"
        elif 45 <= eletkor <= 54:
            if keplet < 22:
                szoveg = "sovány"
            elif 22 <= keplet <= 27:
                szoveg = "ideális"
            elif 27 < keplet <= 32:
                szoveg = "Túlsúly"
            elif 32 < keplet <= 42:
                szoveg = "Elhízott"
            elif 42 < keplet:
                szoveg = "Súlyosan elhízott"
        elif 55 <= eletkor <= 64:
            if keplet < 23:
                szoveg = "sovány"
            elif 23 <= keplet <= 28:
                szoveg = "ideális"
            elif 28 < keplet <= 33:
                szoveg = "Túlsúly"
            elif 33 < keplet <= 43:
                szoveg = "Elhízott"
            elif 43 < keplet:
                szoveg = "Súlyosan elhízott"
        elif 65 <= eletkor:
            if keplet < 24:
                szoveg = "sovány"
            elif 24 <= keplet <= 29:
                szoveg = "ideális"
            elif 29 < keplet <= 34:
                szoveg = "Túlsúly"
            elif 34 < keplet <= 44:
                szoveg = "Elhízott"
            elif 44 < keplet:
                szoveg = "Súlyosan elhízott"
    print("BMI-je:", round(keplet, 1), " és az ön test alkata", szoveg)

    #Itt számolja ki mennyit kell híznia férfinak

    if nem == "Férfi" or nem == "férfi":
        if szoveg == "sovány":
            if 18 <= eletkor <= 24:
                while not 22.5 <= keplet <= 23.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg += 1
                    kg += 1
            elif 25 <= eletkor <= 34:
                while not 23.5 <= keplet <= 24.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg += 1
                    kg += 1
            elif 35 <= eletkor <= 44:
                while not 24.5 <= keplet <= 25.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg += 1
                    kg += 1
            elif 45 <= eletkor <= 54:
                while not 25.5 <= keplet <= 26.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg += 1
                    kg += 1
            elif 55 <= eletkor <= 64:
                while not 26.5 <= keplet <= 27.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg += 1
                    kg += 1
            elif 65 <= eletkor:
                while not 27.5 <= keplet <= 28.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg += 1
                    kg += 1
            print("Önnek ennyi kilogrammot kell híznia:", kg, "kg")

# Itt számolja ki mennyit kell fogyni férfinak

    if nem == "Férfi" or nem == "férfi":
        if szoveg == "Túlsúly" or szoveg == "Elhízott" or szoveg == "Súlyosan elhízott":
            if 18 <= eletkor <= 24:
                while not 22.5 <= keplet <= 23.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg -= 1
                    kg += 1
            elif 25 <= eletkor <= 34:
                while not 23.5 <= keplet <= 24.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg -= 1
                    kg += 1
            elif 35 <= eletkor <= 44:
                while not 24.5 <= keplet <= 25.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg -= 1
                    kg += 1
            elif 45 <= eletkor <= 54:
                while not 25.5 <= keplet <= 26.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg -= 1
                    kg += 1
            elif 55 <= eletkor <= 64:
                while not 26.5 <= keplet <= 27.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg -= 1
                    kg += 1
            elif 65 <= eletkor:
                while not 27.5 <= keplet <= 28.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg -= 1
                    kg += 1
            print("Önnek ennyi kilogrammot kell fogynia:", kg, "kg")

# Itt számolja ki mennyit kell híznia a nőnek

    if nem == "Nő" or nem == "nő":
        if szoveg == "sovány":
            if 18 <= eletkor <= 24:
                while not 21.5 <= keplet <= 22.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg += 1
                    kg += 1
            elif 25 <= eletkor <= 34:
                while not 22.5 <= keplet <= 23.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg += 1
                    kg += 1
            elif 35 <= eletkor <= 44:
                while not 23.5 <= keplet <= 24.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg += 1
                    kg += 1
            elif 45 <= eletkor <= 54:
                while not 24.5 <= keplet <= 25.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg += 1
                    kg += 1
            elif 55 <= eletkor <= 64:
                while not 25.5 <= keplet <= 26.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg += 1
                    kg += 1
            elif 65 <= eletkor:
                while not 26.5 <= keplet <= 27.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg += 1
                    kg += 1
            print("Önnek ennyi kilogrammot kell híznia:", kg, "kg")

# Itt számolja ki mennyit kell fogynia a nőnek

    if nem == "Nő" or nem == "nő":
        if szoveg == "Túlsúly" or szoveg == "Elhízott" or szoveg == "Súlyosan elhízott":
            if 18 <= eletkor <= 24:
                while not 21.5 <= keplet <= 22.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg -= 1
                    kg += 1
            elif 25 <= eletkor <= 34:
                while not 22.5 <= keplet <= 23.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg -= 1
                    kg += 1
            elif 35 <= eletkor <= 44:
                while not 23.5 <= keplet <= 24.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg -= 1
                    kg += 1
            elif 45 <= eletkor <= 54:
                while not 24.5 <= keplet <= 25.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg -= 1
                    kg += 1
            elif 55 <= eletkor <= 64:
                while not 25.5 <= keplet <= 26.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg -= 1
                    kg += 1
            elif 65 <= eletkor:
                while not 26.5 <= keplet <= 27.5:
                    keplet = tomeg / (magassag / 100)**2
                    tomeg -= 1
                    kg += 1
            print("Önnek ennyi kilogrammot kell fogynia:", kg, "kg")
else:
    print(hibauzenet)
